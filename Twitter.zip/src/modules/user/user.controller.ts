import {
  Controller,
  Get,
  Post,
  Body,
  Put,
  Patch,
  Param,
  Delete,
} from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UpdateTweetDto } from '../tweet/dto/update-tweet.dto';
import mongoose from 'mongoose';

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post()
  create(@Body() createUserDto: CreateUserDto) {
    return this.userService.create(createUserDto);
  }

  @Get()
  findAll() {
    return this.userService.findAll();
  }

  @Put()
  update(
    @Body('userId') userId: mongoose.Types.ObjectId,
    updateUserDTO: UpdateUserDto,
  ) {
    return this.userService.update(userId, updateUserDTO);
  }

  @Patch(':userId')
  updateKey(
    @Body('userId') userId: mongoose.Types.ObjectId,
    updateUserDTO: UpdateUserDto,
  ) {
    return this.userService.update(userId, updateUserDTO);
  }

  @Delete(':userID')
  delete(@Param('userID') userId: mongoose.Types.ObjectId) {
    return this.userService.remove(userId);
  }
}
