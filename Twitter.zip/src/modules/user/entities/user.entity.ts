import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import mongoose, { HydratedDocument } from 'mongoose';
import { Tweet } from 'src/modules/tweet/entities/tweet.entity';
import { Image } from 'src/shared/interfaces/media.interface';

export type UserDocument = HydratedDocument<User>;

@Schema()
export class User {
  @Prop({ type: String, required: [true, 'email is missing.'] })
  email: string;

  @Prop({ type: String, required: [true, 'password is missing.'] })
  password: string;

  @Prop({
    type: {
      url: String,
      filename: String,
    },
  })
  profileImage?: Image;

  @Prop({
    type: {
      url: String,
      filename: String,
    },
  })
  coverImage?: Image;

  @Prop({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Tweet' }] })
  likedTweets?: Tweet[];

  @Prop({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Tweet' }] })
  tweets?: Tweet[];

  @Prop({ type: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Tweet' }] })
  repliesTweets?: Tweet[];
}

export const UserSchema = SchemaFactory.createForClass(User);
