export class CreateAuthDto {}
