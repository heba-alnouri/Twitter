import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Put,
  Delete,
} from '@nestjs/common';
import { TweetService } from './tweet.service';
import { CreateTweetDto } from './dto/create-tweet.dto';
import { UpdateTweetDto } from './dto/update-tweet.dto';
import mongoose from 'mongoose';

@Controller('tweet')
export class TweetController {
  constructor(private readonly tweetService: TweetService) {}

  @Post()
  create(@Body() createTweetDto: CreateTweetDto) {
    return this.tweetService.create(createTweetDto);
  }

  @Get()
  findAll() {
    return this.tweetService.findAll();
  }

  @Delete(':tweetID')
  remove(@Body('tweetID') tweetID: mongoose.Types.ObjectId) {
    return this.tweetService.remove(tweetID);
  }

  @Put()
  update(
    @Param('tweetID') tweetID: mongoose.Types.ObjectId,
    @Body() updateTweetDto: UpdateTweetDto,
  ) {
    return this.tweetService.update(tweetID, updateTweetDto);
  }

  @Patch()
  reply(
    @Param('tweetID') tweetId: mongoose.Types.ObjectId,
    @Body() updateTweetDto: UpdateTweetDto,
  ) {
    return this.tweetService.update(tweetId, updateTweetDto);
  }
}
