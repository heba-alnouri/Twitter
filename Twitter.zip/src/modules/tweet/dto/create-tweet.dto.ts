import { IsArray, IsEnum, IsNotEmpty, IsString } from 'class-validator';
import { i18nValidationMessage } from 'nestjs-i18n';
import { User } from 'src/modules/user/entities/user.entity';
import { Image, Video } from 'src/shared/interfaces/media.interface';
import { Tweet } from '../entities/tweet.entity';

export class CreateTweetDto {
  @IsNotEmpty({
    message: i18nValidationMessage(
      'validation.tweetValidation.notEmpty.author',
    ),
  })
  author: User;
  @IsString()
  @IsNotEmpty({
    message: i18nValidationMessage(
      'validation.tweetValidation.notEmpty.tweetContent',
    ),
  })
  tweetContent: string;

  @IsArray()
  retweet: Tweet[] = [];

  @IsArray()
  likes: User[] = [];

  @IsArray()
  mentions: User[] = [];

  @IsArray()
  //   @IsEnum(Image)
  image?: Image[] = [];

  @IsArray()
  video?: Video[] = [];
}
