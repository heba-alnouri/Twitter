export interface ColorScheme {
  messageColor: string;
  contextColor: string;
}
