export interface FileResponse {
  message: string;
  statusCode: number;
  url: string;
}
