export interface Image {
  url: string;
  fileName: string;
}

export interface Video {
  url: string;
  fileName: string;
}
