export enum AccountStatus {
  Active = 1,
  Blocked,
  Restricted = 3,
}
