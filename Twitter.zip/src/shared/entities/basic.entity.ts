// import { Prop } from '@nestjs/mongoose';
// import { Document } from 'mongoose';

// import { currentDate } from '../util/date.util';

// export abstract class Basic extends Document {
//   @Prop({
//     default: currentDate,
//   })
//   updateDate: String;

//   @Prop({
//     default: currentDate,
//   })
//   readonly createDate: String;
// }
// ! change to whatever database you want
