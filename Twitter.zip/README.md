# Nestjs skeleton that contains a custom logger, translation, and a bunch of util
